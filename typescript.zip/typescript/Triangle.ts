/// <reference path = "IShape.ts" /> 
namespace Drawing { 
    export class Triangle implements IShape { 
       public draw():string { 
          return "Triangle is drawn"; 
       } 
    } 
}