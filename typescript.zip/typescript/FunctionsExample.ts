//Named Function
function display() {
    console.log("Hello TypeScript!");
}

display(); //Output: Hello TypeScript 

// function with parameter and return type

function Sum(x: number, y: number) : number {
    return x + y;
}

Sum(2,3); // returns 5

//Anonymous Function
let greeting = function() {
    console.log("Hello TypeScript!");
};

greeting(); //Output: Hello TypeScript! 


let Add = function(x: number, y: number) : number
{
    return x + y;
}

Add(2,3); // returns 5


//Function with Optional Parameter and default argument
function Greet(greeting: string = "Hi", name?: string ) : string {
    if(name!= undefined)
    return greeting + ' ' + name + '!';
    else
    return greeting+' '+"defaultname";
}

Greet('Hello','Steve');//OK, returns "Hello Steve!"
Greet('Welcome'); // OK
console.log(Greet());
console.log(Greet(undefined,"Shalini"));


//Function with rest parameters 
//Remember, rest parameters must come last 
//in the function definition, otherwise the TypeScript compiler will show an error. 
function Greeting(greeting: string, ...names: string[]) {
    return greeting + " " + names.join(", ") + "!";
}

Greeting("Hello", "Steve", "Bill"); // returns "Hello Steve, Bill!"

Greeting("Hello");// returns "Hello !"