/// <reference path = "IShape.ts" /> 
namespace Drawing { 
    export class Circle implements IShape { 
       public draw():string { 
          return "Circle is drawn"; 
       }  
    }
}