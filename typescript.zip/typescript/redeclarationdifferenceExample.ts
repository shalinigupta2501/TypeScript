function varTest(){
    var num1 = 10;	    
    var num1 = 20;  //num1 is replaced
  }

  function letTest(){
    let num1 = 10;	    
    //let num1 = 20;  // SyntaxError: Identifier num1 has already been declared
  }
