namespace Drawing { 
    export interface IShape { 
       draw: ()=>string
       //sayHi: ()=>string 
    }
 } 