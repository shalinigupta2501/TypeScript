function greeter(person) {
    return "Hello, " + person;
}
var user = "Jane User";
var userarray = ["hello", "hi", "world"];
console.log(greeter(user));
