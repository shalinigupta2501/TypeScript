function greeter(person) {
    return "Hello, " + person;
}
var userarray=["hello", "hi","world"]

document.body.innerHTML = greeter(userarray);