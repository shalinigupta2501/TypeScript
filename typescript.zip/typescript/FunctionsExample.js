//Named Function
function display() {
    console.log("Hello TypeScript!");
}
display(); //Output: Hello TypeScript 
// function with parameter and return type
function Sum(x, y) {
    return x + y;
}
Sum(2, 3); // returns 5
//Anonymous Function
var greeting = function () {
    console.log("Hello TypeScript!");
};
greeting(); //Output: Hello TypeScript! 
var Add = function (x, y) {
    return x + y;
};
Add(2, 3); // returns 5
//Function with Optional Parameter and default argument
function Greet(greeting, name) {
    if (greeting === void 0) { greeting = "Hi"; }
    if (name != undefined)
        return greeting + ' ' + name + '!';
    else
        return greeting + ' ' + "defaultname";
}
Greet('Hello', 'Steve'); //OK, returns "Hello Steve!"
Greet('Welcome'); // OK
console.log(Greet());
console.log(Greet(undefined, "Shalini"));
