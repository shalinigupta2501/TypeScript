function throwBack<T>(arg: T): T {    //Function return the parameter as it is
    return arg;
}
 
let outputStr = throwBack<string>("myString");     //OK
console.log(outputStr)
 
let outputNum = throwBack<number>( 100 );      //OK
console.log(outputNum)