function greeter(person:string) {
    return "Hello, " + person;
}

var user = "Jane User";
var userarray=["hello", "hi","world"]

console.log(greeter(user))