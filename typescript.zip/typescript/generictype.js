function throwBack(arg) {
    return arg;
}
var outputStr = throwBack("myString"); //OK
console.log(outputStr);
var outputNum = throwBack(100); //OK
console.log(outputNum);
